Supplementary Materials for submission 1255


# jpg files
- supp_angle.jpg
A picture of a moving angular mechanism of Transcalibur

- supp_weight.jpg
A picture of a moving weight shifting mechanism of Transcalibur

- supp_whole.jpg
A picture of entire Transcalibur working

# GIF files
- supp_angle.gif
A footage of a moving angular mechanism of Transcalibur

- supp_weight.gif
A footage of a moving weight shifting mechanism of Transcalibur

- supp_whole.gif
A footage of entire Transcalibur working

- supp_app.gif
A footage of a uesr wielding Transcalibur in an actual VR experience.